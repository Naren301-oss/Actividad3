package com.nalancode.prueba1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    private EditText etMail,etPass;
    private Button btnIngresar;
    private TextView tvRegistro;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etMail=findViewById(R.id.etEmail);
        etPass=findViewById(R.id.etPass);
        btnIngresar=findViewById(R.id.btnIngresar);
        tvRegistro=findViewById(R.id.tvRegistro);
        mAuth = FirebaseAuth.getInstance();
        tvRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i =new Intent(MainActivity.this,Registro.class);
               startActivity(i);
            }
        });
        btnIngresar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                ingresar(etMail.getText().toString(),etPass.getText().toString());
            }
        });
        }

    private void ingresar(String usuario, String pass) {
        if(usuario.isEmpty()||pass.isEmpty()){
            Toast.makeText(MainActivity.this,"Debe ingresar todos los campos",Toast.LENGTH_LONG).show();
         }else{

            mAuth.signInWithEmailAndPassword(usuario,pass).addOnCompleteListener(this, task -> {
                if(task.isSuccessful()){

                    Toast.makeText(MainActivity.this,"Ingreso correcto",Toast.LENGTH_LONG).show();
                    Intent i =new Intent(MainActivity.this, Gastoo.class);
                    startActivity(i);
                 }else{
                    Toast.makeText(MainActivity.this,"Error al ingresar",Toast.LENGTH_LONG).show();
                 }
            });
        }

    }
}
