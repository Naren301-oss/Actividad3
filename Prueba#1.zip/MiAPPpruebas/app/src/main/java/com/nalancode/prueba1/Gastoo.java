package com.nalancode.prueba1;


import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class Gastoo extends AppCompatActivity {

    private EditText etNombre, etFecha, etCategoria, etTotal;
    private Button btnGuardar, btnBuscar, btnActualizar, btnEliminar;
    private ListView listaGastos;
    private DatabaseReference database;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> lista;
    private String gastoIdActual = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_gastoo);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etNombre = findViewById(R.id.etNombre);
        etFecha = findViewById(R.id.etFecha);
        etCategoria = findViewById(R.id.etCategoria);
        etTotal = findViewById(R.id.etTotal);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnBuscar = findViewById(R.id.btnBuscar);
        btnActualizar = findViewById(R.id.btnActualizar);
        btnEliminar = findViewById(R.id.btnEliminar);
        listaGastos = findViewById(R.id.listaGastos);

        database = FirebaseDatabase.getInstance().getReference("Gastos");
        lista = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista);
        listaGastos.setAdapter(adapter);

        btnGuardar.setOnClickListener(view -> guardarGasto());
        btnBuscar.setOnClickListener(view -> buscarGasto());
        btnActualizar.setOnClickListener(view -> actualizarGasto());
        btnEliminar.setOnClickListener(view -> eliminarGasto());

        mostrarGastos();
    }

    private void guardarGasto() {
        String nombre = etNombre.getText().toString();
        String fecha = etFecha.getText().toString();
        String categoria = etCategoria.getText().toString();
        String totalTexto = etTotal.getText().toString();

        if (nombre.isEmpty() || fecha.isEmpty() || categoria.isEmpty() || totalTexto.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        double total;
        try {
            total = Double.parseDouble(totalTexto);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Total inválido", Toast.LENGTH_SHORT).show();
            return;
        }

        Gasto gasto = new Gasto(nombre, fecha, categoria, total);
        String id = database.push().getKey();
        database.child(id).setValue(gasto).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "Gasto guardado exitosamente", Toast.LENGTH_SHORT).show();
                limpiarCampos();
            } else {
                Toast.makeText(this, "Error al guardar gasto", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void buscarGasto() {
        String nombreBuscado = etNombre.getText().toString();
        if (nombreBuscado.isEmpty()) {
            Toast.makeText(this, "Ingrese el nombre del gasto a buscar", Toast.LENGTH_SHORT).show();
            return;
        }

        database.orderByChild("nombre").equalTo(nombreBuscado).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot data : snapshot.getChildren()) {
                        Gasto gasto = data.getValue(Gasto.class);
                        gastoIdActual = data.getKey();
                        etFecha.setText(gasto.fecha);
                        etCategoria.setText(gasto.categoria);
                        etTotal.setText(String.valueOf(gasto.total));
                        Toast.makeText(Gastoo.this, "Gasto encontrado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                } else {
                    Toast.makeText(Gastoo.this, "Gasto no encontrado", Toast.LENGTH_SHORT).show();
                    gastoIdActual = null;
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(Gastoo.this, "Error al buscar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void actualizarGasto() {
        if (gastoIdActual == null) {
            Toast.makeText(this, "Busque primero un gasto para actualizar", Toast.LENGTH_SHORT).show();
            return;
        }

        String nombre = etNombre.getText().toString();
        String fecha = etFecha.getText().toString();
        String categoria = etCategoria.getText().toString();
        String totalTexto = etTotal.getText().toString();

        if (nombre.isEmpty() || fecha.isEmpty() || categoria.isEmpty() || totalTexto.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        double total;
        try {
            total = Double.parseDouble(totalTexto);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Total inválido", Toast.LENGTH_SHORT).show();
            return;
        }

        Gasto gastoActualizado = new Gasto(nombre, fecha, categoria, total);
        database.child(gastoIdActual).setValue(gastoActualizado).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "Gasto actualizado", Toast.LENGTH_SHORT).show();
                limpiarCampos();
                gastoIdActual = null;
            } else {
                Toast.makeText(this, "Error al actualizar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void eliminarGasto() {
        if (gastoIdActual == null) {
            Toast.makeText(this, "Busque primero un gasto para eliminar", Toast.LENGTH_SHORT).show();
            return;
        }

        database.child(gastoIdActual).removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "Gasto eliminado", Toast.LENGTH_SHORT).show();
                limpiarCampos();
                gastoIdActual = null;
            } else {
                Toast.makeText(this, "Error al eliminar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void mostrarGastos() {
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                lista.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    Gasto gasto = data.getValue(Gasto.class);
                    lista.add(gasto.nombre + " - " + gasto.categoria + " - $" + gasto.total);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(Gastoo.this, "Error al cargar lista", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void limpiarCampos() {
        etNombre.setText("");
        etFecha.setText("");
        etCategoria.setText("");
        etTotal.setText("");
    }

    public static class Gasto {
        public String nombre, fecha, categoria;
        public double total;

        public Gasto() {
        }

        public Gasto(String nombre, String fecha, String categoria, double total) {
            this.nombre = nombre;
            this.fecha = fecha;
            this.categoria = categoria;
            this.total = total;
        }
    }
}